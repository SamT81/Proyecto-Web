package co.edu.javeriana.ejemplojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplojpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
